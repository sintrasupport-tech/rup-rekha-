# 📸 Studio Rup Rekha (स्टूडियो रूप रेखा) — Official Website

> Modern, responsive, and elegant website for **Studio Rup Rekha**, premier photography studio in Bhatta Bazar / Kali Badi Chowk, Purnia, Bihar.

---

## 🌟 Live Demo on GitHub Pages
This project is configured to run directly on **GitHub Pages** with zero setup or build steps.

Once deployed, your website URL will be:
`https://<your-github-username>.github.io/<your-repo-name>/`

---

## 🚀 How to Run & Deploy on GitHub Pages (Step-by-Step)

### Method 1: Upload via GitHub Website (Easiest - 2 Minutes)

1. Go to [github.com/new](https://github.com/new) and log into your GitHub account.
2. Enter a **Repository name** (e.g., `studio-rup-rekha` or `studio-rup-rekha-purnia`).
3. Set the repository to **Public**.
4. Click **Create repository**.
5. On the next screen, click the link: **"uploading an existing file"**.
6. Drag and drop all the files from your folder:
   - `index.html`
   - `styles.css`
   - `app.js`
   - `README.md`
7. Click the green **Commit changes** button.
8. Go to **Settings** (tab at top of repository) ➔ **Pages** (in the left sidebar).
9. Under **Build and deployment**:
   - Source: Select **Deploy from a branch**
   - Branch: Select **`main`** (or `master`) and folder **`/ (root)`**
   - Click **Save**.
10. Refresh after ~30 seconds, and your live website URL will appear at the top of the Pages screen!

---

### Method 2: Deploy using Git CLI (PowerShell / Terminal)

Open PowerShell inside this folder and run:

```powershell
# 1. Initialize Git repository
git init

# 2. Add all files
git add .

# 3. Commit changes
git commit -m "Initial commit for Studio Rup Rekha website"

# 4. Set main branch
git branch -M main

# 5. Link to your GitHub repository (replace USERNAME and REPO_NAME)
git remote add origin https://github.com/USERNAME/REPO_NAME.git

# 6. Push code to GitHub
git push -u origin main
```

Then enable GitHub Pages in your repo: **Settings ➔ Pages ➔ Source: `main` ➔ Save**.

---

## 📁 Project Structure

```
studio-rup-rekha/
├── index.html        # Main webpage (Hero, Services, Gallery, Restoration, Location, Form)
├── styles.css        # Custom CSS animations & comparison slider styles
├── app.js            # Live operating status, filterable gallery, lightbox & WhatsApp booking
├── README.md         # Documentation & GitHub deployment instructions
└── .github/
    └── workflows/
        └── deploy.yml # Automated GitHub Actions deployment workflow
```

---

## 📞 Studio Contact Details

- **Name**: Studio Rup Rekha (स्टूडियो रूप रेखा)
- **Phone**: `091134 30237`
- **Address**: Kali Badi Chowk, Near Bhatta Bazar, Purnia, Bihar 854301
- **Plus Code**: `QFCH+C2 Purnia, Bihar`
- **Hours**: Open Daily, 9:00 AM – 7:00 PM
