/**
 * Studio Rup Rekha - JavaScript Interaction Controller
 */

document.addEventListener('DOMContentLoaded', () => {
  // 1. Initialize Lucide Icons
  if (window.lucide) {
    lucide.createIcons();
  }

  // 2. Set Current Year in Footer
  const currentYearSpan = document.getElementById('currentYear');
  if (currentYearSpan) {
    currentYearSpan.textContent = new Date().getFullYear();
  }

  // 3. Dynamic Studio Operating Status Indicator
  updateStudioStatus();
  setInterval(updateStudioStatus, 60000); // Check every minute

  function updateStudioStatus() {
    const now = new Date();
    // Studio hours: Open daily 9:00 AM (9) to 7:00 PM (19)
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();
    const currentTimeDecimal = currentHour + currentMinute / 60;

    const openTime = 9.0; // 9:00 AM
    const closeTime = 19.0; // 7:00 PM

    const statusBadge = document.getElementById('liveStatusBadge');
    const statusText = document.getElementById('liveStatusText');
    const hoursDetailText = document.getElementById('hoursDetailText');

    const isOpen = currentTimeDecimal >= openTime && currentTimeDecimal < closeTime;

    if (isOpen) {
      if (statusBadge) {
        statusBadge.className = "flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30";
      }
      if (statusText) {
        statusText.textContent = "Open Now · Closes at 7:00 PM";
      }
      if (hoursDetailText) {
        hoursDetailText.textContent = "Open Today · Closes at 7:00 PM";
      }
    } else {
      if (statusBadge) {
        statusBadge.className = "flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/30";
      }
      if (statusText) {
        statusText.textContent = "Closed · Opens Tomorrow at 9:00 AM";
      }
      if (hoursDetailText) {
        hoursDetailText.textContent = "Closed · Opens at 9:00 AM Daily";
      }
    }
  }

  // 4. Mobile Menu Drawer Toggle
  const mobileMenuBtn = document.getElementById('mobileMenuBtn');
  const mobileMenu = document.getElementById('mobileMenu');
  const menuIcon = document.getElementById('menuIcon');
  const closeIcon = document.getElementById('closeIcon');

  if (mobileMenuBtn && mobileMenu) {
    mobileMenuBtn.addEventListener('click', () => {
      const isHidden = mobileMenu.classList.toggle('hidden');
      if (menuIcon && closeIcon) {
        menuIcon.classList.toggle('hidden', !isHidden);
        closeIcon.classList.toggle('hidden', isHidden);
      }
    });

    // Close menu when a link is clicked
    document.querySelectorAll('.mobile-nav-link').forEach(link => {
      link.addEventListener('click', () => {
        mobileMenu.classList.add('hidden');
        if (menuIcon && closeIcon) {
          menuIcon.classList.remove('hidden');
          closeIcon.classList.add('hidden');
        }
      });
    });
  }

  // 5. Gallery Filter Tabs
  const filterButtons = document.querySelectorAll('.gallery-tab');
  const galleryItems = document.querySelectorAll('.gallery-item');

  filterButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      // Update tab active state
      filterButtons.forEach(b => {
        b.classList.remove('active', 'bg-amber-400', 'text-neutral-950');
        b.classList.add('bg-neutral-800', 'text-neutral-300');
      });
      btn.classList.add('active', 'bg-amber-400', 'text-neutral-950');
      btn.classList.remove('bg-neutral-800', 'text-neutral-300');

      const filter = btn.getAttribute('data-filter');

      galleryItems.forEach(item => {
        const itemCategory = item.getAttribute('data-category');
        if (filter === 'all' || itemCategory === filter) {
          item.classList.remove('hidden-item');
          item.style.display = 'block';
        } else {
          item.classList.add('hidden-item');
          item.style.display = 'none';
        }
      });
    });
  });

  // 6. Gallery Lightbox Modal
  const lightboxModal = document.getElementById('lightboxModal');
  const lightboxImg = document.getElementById('lightboxImg');
  const lightboxTitle = document.getElementById('lightboxTitle');
  const lightboxDesc = document.getElementById('lightboxDesc');
  const closeLightbox = document.getElementById('closeLightbox');
  const prevLightbox = document.getElementById('prevLightbox');
  const nextLightbox = document.getElementById('nextLightbox');

  let currentGalleryIndex = 0;
  const visibleItems = () => Array.from(galleryItems).filter(item => !item.classList.contains('hidden-item'));

  function openLightbox(index) {
    const items = visibleItems();
    if (index < 0) index = items.length - 1;
    if (index >= items.length) index = 0;
    currentGalleryIndex = index;

    const currentItem = items[currentGalleryIndex];
    if (!currentItem) return;

    const src = currentItem.getAttribute('data-src') || currentItem.querySelector('img').src;
    const title = currentItem.getAttribute('data-title') || '';
    const desc = currentItem.getAttribute('data-desc') || '';

    lightboxImg.src = src;
    lightboxTitle.textContent = title;
    lightboxDesc.textContent = desc;

    lightboxModal.classList.remove('hidden');
    lightboxModal.classList.add('flex');
    document.body.style.overflow = 'hidden';
  }

  function closeLightboxModal() {
    lightboxModal.classList.add('hidden');
    lightboxModal.classList.remove('flex');
    document.body.style.overflow = 'auto';
  }

  galleryItems.forEach((item) => {
    item.addEventListener('click', () => {
      const items = visibleItems();
      const index = items.indexOf(item);
      openLightbox(index);
    });
  });

  if (closeLightbox) {
    closeLightbox.addEventListener('click', closeLightboxModal);
  }

  if (prevLightbox) {
    prevLightbox.addEventListener('click', (e) => {
      e.stopPropagation();
      openLightbox(currentGalleryIndex - 1);
    });
  }

  if (nextLightbox) {
    nextLightbox.addEventListener('click', (e) => {
      e.stopPropagation();
      openLightbox(currentGalleryIndex + 1);
    });
  }

  if (lightboxModal) {
    lightboxModal.addEventListener('click', (e) => {
      if (e.target === lightboxModal) {
        closeLightboxModal();
      }
    });
  }

  // Keyboard navigation for lightbox
  document.addEventListener('keydown', (e) => {
    if (!lightboxModal || lightboxModal.classList.contains('hidden')) return;

    if (e.key === 'Escape') {
      closeLightboxModal();
    } else if (e.key === 'ArrowLeft') {
      openLightbox(currentGalleryIndex - 1);
    } else if (e.key === 'ArrowRight') {
      openLightbox(currentGalleryIndex + 1);
    }
  });

  // 7. Interactive Before/After Restoration Slider
  const compareRange = document.getElementById('compareRange');
  const compareBeforeWrapper = document.getElementById('compareBeforeWrapper');
  const compareSliderHandle = document.getElementById('compareSliderHandle');

  if (compareRange && compareBeforeWrapper && compareSliderHandle) {
    compareRange.addEventListener('input', (e) => {
      const value = e.target.value;
      compareBeforeWrapper.style.width = `${value}%`;
      compareSliderHandle.style.left = `${value}%`;
    });
  }

  // 8. Booking Form Handler (Generates WhatsApp prefilled message & redirects)
  const bookingForm = document.getElementById('bookingForm');
  if (bookingForm) {
    bookingForm.addEventListener('submit', (e) => {
      e.preventDefault();

      const name = document.getElementById('clientName')?.value || '';
      const phone = document.getElementById('clientPhone')?.value || '';
      const service = document.getElementById('serviceType')?.value || '';
      const date = document.getElementById('preferredDate')?.value || 'Flexible';
      const notes = document.getElementById('clientNotes')?.value || 'None';

      const message = `*Photography Booking Request - Studio Rup Rekha*\n\n` +
        `👤 *Client Name:* ${name}\n` +
        `📞 *Phone:* ${phone}\n` +
        `📸 *Service Requested:* ${service}\n` +
        `📅 *Preferred Date:* ${date}\n` +
        `📝 *Special Notes:* ${notes}\n\n` +
        `_Sent via Studio Rup Rekha Website (Purnia, Bihar)_`;

      const encodedMessage = encodeURIComponent(message);
      const whatsappUrl = `https://wa.me/919113430237?text=${encodedMessage}`;

      window.open(whatsappUrl, '_blank');
    });
  }

  // 9. Active Link Scroll Spy
  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('nav a.nav-link');

  window.addEventListener('scroll', () => {
    let current = '';
    const scrollY = window.pageYOffset;

    sections.forEach(section => {
      const sectionHeight = section.offsetHeight;
      const sectionTop = section.offsetTop - 120;
      const sectionId = section.getAttribute('id');

      if (scrollY >= sectionTop && scrollY < sectionTop + sectionHeight) {
        current = sectionId;
      }
    });

    navLinks.forEach(link => {
      link.classList.remove('text-amber-400');
      if (link.getAttribute('href') === `#${current}`) {
        link.classList.add('text-amber-400');
      }
    });
  });
});
